package com.example.chung.work;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private EditText account_edt;
    private EditText password_edt;
    private Button register_btn;
    private Button login_btn;
   //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout1);

        initView();
    }

    private void initView(){
        register_btn = (Button) findViewById(R.id.register);
        login_btn = (Button) findViewById(R.id.login);
        account_edt = (EditText) findViewById(R.id.account_edit);
        password_edt = (EditText) findViewById(R.id.password_edit);

        //
        register_btn.setOnClickListener(this);
        login_btn.setOnClickListener(this);
    }


    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.register:
                intent = new Intent(this,act_2.class);
                startActivity(intent);
                break;

            case R.id.login:
                intent = new Intent(this,act_4.class);
                startActivity(intent);
                break;

            default:
                break;
        }
    }
}
