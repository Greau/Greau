package com.example.chung.work;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

/**
 * Created by chung on 2017/10/1.
 */

public class act_10 extends Activity  implements View.OnClickListener,View.OnLayoutChangeListener{
    private ImageButton returnBtn;
    private ImageButton messageBtn;
    private ImageButton roomBtn;
    private ImageButton setting;
    private RelativeLayout rl;
    private LinearLayout ll;
    private EditText searchFriendEdt;
    private ListView friendList;

    private ArrayAdapter<String> friendListAdapter;
    private boolean isFirst;



    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout10);
        init();
    }

    private void init(){
        initView();
        initData();
    }

    private void initData(){
        isFirst = true;
        setApt();
    }

    private void initView(){
        returnBtn = (ImageButton) findViewById(R.id.friendListReturnBtn);
        messageBtn = (ImageButton) findViewById(R.id.messageBtn);
        roomBtn = (ImageButton) findViewById(R.id.roomBtn);
        setting = (ImageButton) findViewById(R.id.setting);
        searchFriendEdt = (EditText) findViewById(R.id.searchFriend);
        friendList = (ListView) findViewById(R.id.friend_list);
        rl = (RelativeLayout) findViewById(R.id.rl);
        ll = (LinearLayout) findViewById(R.id.temp10_2);

        returnBtn.setOnClickListener(this);
        messageBtn.setOnClickListener(this);
        roomBtn.setOnClickListener(this);
        setting.setOnClickListener(this);
        rl.addOnLayoutChangeListener(this);
    }

    private void setApt(){
        final String[] strs =  { "abc", "abcd", "bcd", "bcde", "bcde","bcde", "bcde"  };
        friendListAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, strs);
        friendList.setAdapter(friendListAdapter);

        friendList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(act_10.this, act_18.class);
                intent.putExtra("Goods",strs[position]);
                startActivity(intent);
            }
        });
    }



    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.friendListReturnBtn:
                finish();
                break;
            case R.id.messageBtn:
                Intent intent1 = new Intent(act_10.this, act_17.class);
                startActivity(intent1);
                break;

            case R.id.roomBtn:
                break;
            case R.id.setting:
                break;
            case R.id.searchFriend:

            default:
                break;
        }
    }

    /**
     * Called when the layout bounds of a view changes due to layout processing.
     *
     * @param v         The view whose bounds have changed.
     * @param left      The new value of the view's left property.
     * @param top       The new value of the view's top property.
     * @param right     The new value of the view's right property.
     * @param bottom    The new value of the view's bottom property.
     * @param oldLeft   The previous value of the view's left property.
     * @param oldTop    The previous value of the view's top property.
     * @param oldRight  The previous value of the view's right property.
     * @param oldBottom The previous value of the view's bottom property.
     */
    @Override
    public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
        if(Math.abs(oldBottom - bottom) > 50){
            if(isFirst){
                isFirst = false;
            }else{
                int temp;
                if(ll.getVisibility() == View.GONE) temp = View.VISIBLE;
                else temp = View.GONE;
                ll.setVisibility(temp);
            }
        }

    }
}
