package com.example.chung.work;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

/**
 * Created by chung on 2017/10/1.
 */

public class act_11 extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout11);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {

    }
}
