package com.example.chung.work;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;


/**
 * Created by chung on 2017/9/30.
 */

public class act_13 extends Activity implements View.OnClickListener{
    private ImageButton returnBtn;
    private EditText noteEdt;
    private EditText descriptif;
    private Button friendVisibilityBtn;
    private Button allSelectBtn;
    private Button resetBtn;
    private Button deleteBtn;
    private LinearLayout linearLayout;
    private ListView friendVisibilityList;
    //

    private ArrayAdapter<String> friendListAdapter;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout13);
        initView();
        serApt();
    }

    private void initView(){
        returnBtn = (ImageButton) findViewById(R.id.reBtn);
        noteEdt = (EditText) findViewById(R.id.noteEdt);
        descriptif = (EditText) findViewById(R.id.descriptifEdt);
        friendVisibilityBtn = (Button) findViewById(R.id.friendVisibility);
        allSelectBtn = (Button) findViewById(R.id.allSelectBtn);
        resetBtn = (Button) findViewById(R.id.resetBtn);
        deleteBtn = (Button) findViewById(R.id.deleteBtn);
        linearLayout = (LinearLayout) findViewById(R.id.temp13_5);
        friendVisibilityList = (ListView) findViewById(R.id.friendVisibilityList);

        returnBtn.setOnClickListener(this);
        friendVisibilityBtn.setOnClickListener(this);
        allSelectBtn.setOnClickListener(this);
        resetBtn.setOnClickListener(this);
        deleteBtn.setOnClickListener(this);

    }

    private void serApt(){
        final String[] strs =  { "abc", "abcd", "bcd", "bcde", "bcde","bcde", "bcde"  };
        friendListAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, strs);
        friendVisibilityList.setAdapter(friendListAdapter);

        friendVisibilityList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.reBtn:
                finish();
                break;

            case R.id.friendVisibility:
                int temp;
                if(linearLayout.getVisibility() == View.GONE) temp = View.VISIBLE;
                else temp = View.GONE;
                linearLayout.setVisibility(temp);
                friendVisibilityList.setVisibility(temp);
                break;

            case R.id.deleteBtn:
                break;

            case R.id.allSelectBtn:
                break;

            case R.id.resetBtn:
                break;

            default:
                break;
        }
    }
}
