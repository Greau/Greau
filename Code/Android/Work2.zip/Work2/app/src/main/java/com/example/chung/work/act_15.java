package com.example.chung.work;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

/**
 * Created by chung on 2017/10/1.
 */

public class act_15 extends Activity implements View.OnClickListener{
    private ImageButton setBtn;
    private ImageButton returnBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout5);
        initView();
    }

    private void initView(){
        setBtn = (ImageButton) findViewById(R.id.setBtn);
        returnBtn = (ImageButton) findViewById(R.id.returnBtn) ;

        setBtn.setOnClickListener(this);
        returnBtn.setOnClickListener(this);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.setBtn:
                Intent intent = new Intent(act_15.this, act_16.class);
                startActivity(intent);
                break;

            case R.id.returnBtn:
                finish();
            default:
                break;
        }
    }
}
