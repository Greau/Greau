package com.example.chung.work;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by chung on 2017/10/1.
 */

public class act_16 extends Activity implements View.OnClickListener{
    private ImageButton returnBtn;
    private ImageButton addBtn;
    private EditText roomNameEdt;
    private TextView creatorTv;
    private Button admorBtn;
    private Button otherBtn;
    private ImageButton quitBtn;
    private ListView admorList;
    private ListView otherList;
    //

    private ArrayAdapter<String> admorAdapter;
    private ArrayAdapter<String> otherAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout16);
        initView();
        setApt();
    }

    private void initView(){
        returnBtn = (ImageButton) findViewById(R.id.setPublicReturnBtn);
        roomNameEdt = (EditText) findViewById(R.id.publicRoomNameEdt);
        creatorTv = (TextView) findViewById(R.id.creator);
        admorBtn = (Button) findViewById(R.id.admor);
        otherBtn = (Button) findViewById(R.id.other);
        quitBtn = (ImageButton) findViewById(R.id.quitPublicBtn);
        addBtn = (ImageButton) findViewById(R.id.addFriendBtn);
        admorList = (ListView) findViewById(R.id.admorList);
        otherList = (ListView) findViewById(R.id.otherList);

        returnBtn.setOnClickListener(this);
        admorBtn.setOnClickListener(this);
        otherBtn.setOnClickListener(this);
        quitBtn.setOnClickListener(this);
        addBtn.setOnClickListener(this);

    }

    private void setApt(){
        setAdmorApt();
        setOtherApt();
    }

    private void setAdmorApt(){
        final String[] strs =  { "abc", "abcd", "bcd", "bcde" };
        admorAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, strs);
        admorList.setAdapter(admorAdapter);

        admorList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(act_16.this, act_19.class);
                intent.putExtra("RoomName", strs[position]);
                startActivity(intent);
            }
        });
    }

    private void setOtherApt(){
        final String[] strs =  { "张三", "李四", "王朝", "包拯" };
        otherAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, strs);
        otherList.setAdapter(otherAdapter);

        otherList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(act_16.this, act_19.class);
                intent.putExtra("RoomName", strs[position]);
                startActivity(intent);
            }
        });
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.setPublicReturnBtn:
                finish();
                break;
            case R.id.admor:
                int temp1;
                if(admorList.getVisibility() == View.GONE) temp1 = View.VISIBLE;
                else temp1 = View.GONE;
                admorList.setVisibility(temp1);
                break;

            case R.id.other:
                int temp2;
                if(otherList.getVisibility() == View.GONE) temp2 = View.VISIBLE;
                else temp2 = View.GONE;
                otherList.setVisibility(temp2);
                break;

            case R.id.quitPublicBtn:

                finish();
                break;

            case R.id.addFriendBtn:
                break;

            default:
                break;
        }
    }
}
