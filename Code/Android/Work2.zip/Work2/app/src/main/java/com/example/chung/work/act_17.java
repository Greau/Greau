package com.example.chung.work;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;


/**
 * Created by chung on 2017/10/3.
 */

public class act_17 extends Activity implements View.OnClickListener{
    private ImageButton returnBtn;
    private ImageButton connectorBtn;
    private ImageButton roomBtn;
    private ImageButton setBtn;
    //

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout17);
        init();
    }

    private void init(){
        initView();
    }

    private void initView(){
        returnBtn = (ImageButton) findViewById(R.id.returnBtn17);
        connectorBtn = (ImageButton) findViewById(R.id.conectorBtn);
        roomBtn = (ImageButton) findViewById(R.id.roomBtn);
        setBtn = (ImageButton) findViewById(R.id.setting);

        returnBtn.setOnClickListener(this);
        connectorBtn.setOnClickListener(this);
        roomBtn.setOnClickListener(this);
        setBtn.setOnClickListener(this);

    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.returnBtn17:
                finish();
                break;


            //存在堆栈问题
            case R.id.conectorBtn:
                Intent intent1 = new Intent(act_17.this,act_10.class);
                startActivity(intent1);
                break;

            case R.id.roomBtn:
                break;

            case R.id.setting:
                /*
                Intent intent3 = new Intent(act_17.this, act_13.class);
                startActivity(intent3);*/
                break;

            default:
                break;
        }
    }
}
