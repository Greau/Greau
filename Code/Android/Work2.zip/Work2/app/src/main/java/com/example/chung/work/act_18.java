package com.example.chung.work;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

/**
 * Created by chung on 2017/10/1.
 */

public class act_18 extends Activity implements View.OnClickListener{
    private ImageButton returnBtn;
    private Button deleteFriendBtn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout18);
        initView();
    }

    private void initView(){
        returnBtn = (ImageButton) findViewById(R.id.friendMeReturnBtn);
        deleteFriendBtn = (Button) findViewById(R.id.deleteFriend);

        returnBtn.setOnClickListener(this);
        deleteFriendBtn.setOnClickListener(this);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.friendMeReturnBtn:
                finish();
                break;

            case R.id.deleteFriend:

                finish();
                break;

            default:
                break;
        }
    }
}
