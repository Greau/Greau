package com.example.chung.work;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by chung on 2017/10/1.
 */

public class act_19 extends Activity implements View.OnClickListener {
    private ImageButton returnBtn;
    private ImageView friendAvatar;
    private TextView friendName;
    private Button removeBtn;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout19);
        initView();
    }

    private void initView(){
        returnBtn = (ImageButton) findViewById(R.id.roomPeopleReturnBtn);
        friendAvatar = (ImageView) findViewById(R.id.friendAvatar);
        friendName = (TextView) findViewById(R.id.roomPeopleNameTv);
        removeBtn = (Button) findViewById(R.id.removePeopleBtn);

        returnBtn.setOnClickListener(this);
        removeBtn.setOnClickListener(this);
    }

    /**
     *
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.roomPeopleReturnBtn:
                finish();
                break;
            case R.id.removePeopleBtn:

                finish();
                break;

            default:
                break;
        }
    }
}
