package com.example.chung.work;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


/**
 * Created by chung on 2017/9/29.
 */

public class act_2 extends Activity implements View.OnClickListener{
    private EditText phoneNumberEdt;
    private EditText checkNumberEdt;
    private Button checkNumberBtn;
    private Button registerBtn;
    private Button returnBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout2);
        initView();
    }

    private void initView(){
        phoneNumberEdt = (EditText) findViewById(R.id.phoneNumber);
        checkNumberEdt = (EditText) findViewById(R.id.checkNumber);
        checkNumberBtn = (Button) findViewById(R.id.checkNumberBtn);
        registerBtn = (Button) findViewById(R.id.registerBtn);
        returnBtn = (Button) findViewById(R.id.returnBtn);

        checkNumberBtn.setOnClickListener(this);
        registerBtn.setOnClickListener(this);
        returnBtn.setOnClickListener(this);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.checkNumberBtn:
                break;

            case R.id.registerBtn:
                Intent intent = new Intent(this, act_3.class);
                startActivity(intent);
                finish();
                break;

            case R.id.returnBtn:
                finish();
                break;

            default:
                break;
        }
    }
}
