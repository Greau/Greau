package com.example.chung.work;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by chung on 2017/9/30.
 */

public class act_3 extends Activity implements View.OnClickListener{
    private EditText nickNameEdt;
    private EditText passwordEdt;
    private EditText passwordAgainEdt;
    private Button commitBtn;
    private Button returnBtn;
    //

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout3);
        initView();
    }

    private void initView(){
        nickNameEdt = (EditText) findViewById(R.id.nickNameEdt);
        passwordEdt = (EditText) findViewById(R.id.passwordEdt);
        passwordAgainEdt = (EditText) findViewById(R.id.passwordAgainEdt);

        commitBtn = (Button) findViewById(R.id.commitBtn);
        returnBtn = (Button) findViewById(R.id.returnBtn);

        commitBtn.setOnClickListener(this);
        returnBtn.setOnClickListener(this);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.commitBtn:
                finish();
                break;

            case R.id.returnBtn:
                finish();
                break;

            default:
                break;
        }
    }
}
