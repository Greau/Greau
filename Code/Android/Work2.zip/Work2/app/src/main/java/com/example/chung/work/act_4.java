package com.example.chung.work;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;


/**
 * Created by chung on 2017/9/28.
 */

public class act_4 extends Activity implements View.OnClickListener{
    private AutoCompleteTextView search;
    private Button publicRoomBtn;
    private Button privateRoomBtn;
    private ImageButton freindListBtn;
    private ImageButton setBtn;
    private ImageButton searchOneBtn;
    private ImageButton PublicRoomBtn;
    private ImageButton PrivateRoomBtn;
    private ImageButton returnBtn;
    private ImageButton addBtn;
    private ListView listPublicRoom;
    private ListView listPrivateRoom;
    private LinearLayout linearLayout;

    //
    private ArrayAdapter<String> searchAdapter;
    private ArrayAdapter<String> publicRoomAdapter;
    private ArrayAdapter<String> privateRoomAdapter;
    private boolean isFirst;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout4);
        init();
    }

    private void init(){
        initView();
        initData();
    }


    private void initData(){
        isFirst = true;
        mySetAdapter();
    }

    private void initView(){
        search = (AutoCompleteTextView) findViewById(R.id.seach);
        publicRoomBtn = (Button) findViewById(R.id.publicRoomBtn);
        privateRoomBtn = (Button) findViewById(R.id.privateRoomBtn);
        freindListBtn = (ImageButton) findViewById(R.id.friendListBtn);
        setBtn = (ImageButton) findViewById(R.id.setBtn);
        searchOneBtn = (ImageButton) findViewById(R.id.searchOneBtn);
        PublicRoomBtn = (ImageButton) findViewById(R.id.PublicRoomBtn);
        PrivateRoomBtn = (ImageButton) findViewById(R.id.PrivateRoomBtn);
        returnBtn = (ImageButton) findViewById(R.id.returnBtn4);
        addBtn = (ImageButton) findViewById(R.id.addSearch);
        listPrivateRoom = (ListView) findViewById(R.id.listPrivateRoom);
        listPublicRoom = (ListView) findViewById(R.id.listPublicRoom);
        linearLayout = (LinearLayout) findViewById(R.id.linetemp);

        publicRoomBtn.setOnClickListener(this);
        privateRoomBtn.setOnClickListener(this);
        setBtn.setOnClickListener(this);
        freindListBtn.setOnClickListener(this);
        searchOneBtn.setOnClickListener(this);
        PublicRoomBtn.setOnClickListener(this);
        PrivateRoomBtn.setOnClickListener(this);
        returnBtn.setOnClickListener(this);
        addBtn.setOnClickListener(this);

    }

    private void mySetAdapter(){
        setSearchAdapter();
        setPrivateRoomAdapter();
        setPublicRoomAdapter();
    }


    private void setSearchAdapter(){
        String[] strs =  { "abc", "abcd", "bcd", "bcde" };
        searchAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, strs);
        search.setAdapter(searchAdapter);
    }

    private void setPublicRoomAdapter(){
        final String[] strs =  { "abc", "abcd", "bcd", "bcde" };
        publicRoomAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line , strs);
        listPublicRoom.setAdapter(publicRoomAdapter);
        listPublicRoom.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(act_4.this, act_15.class);
                intent.putExtra("RoomName", strs[position]);
                startActivity(intent);
            }
        });
    }

    private void setPrivateRoomAdapter(){
        final String[] strs =  { "abc", "abcddfjldjkjdjfdjfkd", "bcd", "bcde","bcd", "bcde" };
        privateRoomAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, strs);
        listPrivateRoom.setAdapter(privateRoomAdapter);
        listPrivateRoom.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(act_4.this, act_5.class);
                intent.putExtra("RoomName", strs[position]);
                startActivity(intent);
            }
        });
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.publicRoomBtn:
                break;

            case R.id.privateRoomBtn:
                int temp2;
                if(listPrivateRoom.getVisibility() == View.GONE) temp2 = View.VISIBLE;
                else temp2 = View.GONE;
                listPrivateRoom.setVisibility(temp2);
                break;

            case R.id.friendListBtn:
                Intent intent1 = new Intent(act_4.this, act_10.class);
                startActivity(intent1);
                break;

            case R.id.setBtn:
                Intent intent2 = new Intent(act_4.this, act_7.class);
                startActivity(intent2);
                break;

            case R.id.searchOneBtn:
                break;

            case R.id.PublicRoomBtn:
                int temp1;
                if(listPublicRoom.getVisibility() == View.GONE) temp1 = View.VISIBLE;
                else temp1 = View.GONE;
                listPublicRoom.setVisibility(temp1);
                break;

            case R.id.PrivateRoomBtn:
                int temp3;
                if(listPrivateRoom.getVisibility() == View.GONE) temp3 = View.VISIBLE;
                else temp3 = View.GONE;
                listPrivateRoom.setVisibility(temp3);
                break;

            case R.id.returnBtn4:
                finish();
                break;

            case R.id.addSearch:
                linearLayout.setVisibility(View.VISIBLE);
                break;

            default:
                break;
        }
    }
}
