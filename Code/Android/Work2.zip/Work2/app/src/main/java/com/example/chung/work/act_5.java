package com.example.chung.work;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


/**
 * Created by chung on 2017/9/30.
 */

public class act_5 extends Activity implements View.OnClickListener{
    private TextView RoomName;
    private ImageButton addBtn;
    private ImageButton setBtn;
    private ImageButton returnBtn;
    private String RoomNameStr;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout5);
        initView();
        setRoomNameStr();
    }

    private void setRoomNameStr(){
        Intent intent = this.getIntent();
        RoomNameStr = intent.getStringExtra("RoomName");

        RoomName.setText(RoomNameStr);
    }

    private void initView(){
        RoomName = (TextView) findViewById(R.id.RoomName);
        addBtn = (ImageButton) findViewById(R.id.add);
        setBtn = (ImageButton) findViewById(R.id.setBtn);
        returnBtn = (ImageButton) findViewById(R.id.returnBtn);


        addBtn.setOnClickListener(this);
        setBtn.setOnClickListener(this);
        returnBtn.setOnClickListener(this);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.add:
                Toast.makeText(this,"add 功能暂未开放",Toast.LENGTH_SHORT).show();
                break;

            case R.id.setBtn:
                Intent intent = new Intent(this, act_6.class);
                intent.putExtra("RoomName", RoomNameStr);
                startActivity(intent);
                break;

            case R.id.returnBtn:
                finish();
                break;

            default:
                break;
        }
    }
}
