package com.example.chung.work;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.inputmethodservice.InputMethodService;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.Toast;

/**
 * Created by chung on 2017/9/30.
 */

public class act_6 extends Activity implements View.OnClickListener{
    private ImageButton returnBtn;
    private Button roomScale;
    private Button roomGoods;
    private Button someCanBtn;
    private Button saveBtn;
    private Switch allCanSwitch;
    private EditText roomNameEdt;
    private ListView someOneCanList;
    private ListView goodList;
    private RelativeLayout ttt;
    //

    private ArrayAdapter<String> someOneCanAdapter;
    private ArrayAdapter<String> roomGoodsAdapter;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout6);
        init();
    }

    private void init(){
        initView();
        initData();
    }

    private void initData(){
        setFriendApt();
        setGoodApt();
    }

    private void initView(){
        returnBtn = (ImageButton) findViewById(R.id.roomReturnBtn);
        //roomScale = (Button) findViewById(R.id.scale);
        roomGoods = (Button) findViewById(R.id.goods);
        someCanBtn = (Button) findViewById(R.id.someOneCanBtn);
        saveBtn = (Button) findViewById(R.id.savaBtn);
        allCanSwitch = (Switch) findViewById(R.id.allCanSwitch);
        roomNameEdt = (EditText) findViewById(R.id.RoomNameEdt);
        someOneCanList = (ListView) findViewById(R.id.someOneCanList);
        goodList = (ListView) findViewById(R.id.goodList);
        ttt = (RelativeLayout) findViewById(R.id.temp);


        returnBtn.setOnClickListener(this);
        //roomScale.setOnClickListener(this);
        roomGoods.setOnClickListener(this);
        someCanBtn.setOnClickListener(this);
        saveBtn.setOnClickListener(this);
        ttt.setOnClickListener(this);
    }

    private void setGoodApt(){
        final String[] strs =  { "abc", "abcd", "bcd", "bcde", "bcde","bcde", "gcde"  };
        roomGoodsAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, strs);
        goodList.setAdapter(roomGoodsAdapter);

        goodList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(act_6.this,act_13.class);
                intent.putExtra("Goods",strs[position]);
                startActivity(intent);
            }
        });
    }

    private void setFriendApt(){
        final String[] strs =  { "abc", "abcd", "bcd", "bcde", "bcde","bcde", "www"  };
        someOneCanAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, strs);
        someOneCanList.setAdapter(someOneCanAdapter);

        someOneCanList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(act_6.this, act_13.class);
                intent.putExtra("Goods",strs[position]);
                startActivity(intent);
            }
        });
    }


    private void showDialog(){
        final  AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("您确定要修改？");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.setNeutralButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog ad = builder.create();
        Window window = ad.getWindow();
        window.setGravity(Gravity.CENTER);
        window.setWindowAnimations(R.style.popupAnimation);
        ad.show();

    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        if(v.getId() != R.id.RoomNameEdt){
            roomNameEdt.clearFocus();
            InputMethodManager imm = (InputMethodManager)getSystemService(InputMethodService.INPUT_METHOD_SERVICE);
            if(imm.isActive()&&getCurrentFocus()!=null){
                if (getCurrentFocus().getWindowToken()!=null) {
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
            }
        }

        switch (v.getId()){
            case R.id.roomReturnBtn:
                finish();
                break;

            //case R.id.scale:
               // break;

            case R.id.goods:
                int temp1;
                if(goodList.getVisibility() == View.GONE) temp1 = View.VISIBLE;
                else temp1 = View.GONE;
                goodList.setVisibility(temp1);
                break;

            case R.id.someOneCanBtn:
                int temp2;
                if(someOneCanList.getVisibility() == View.GONE) temp2 = View.VISIBLE;
                else temp2 = View.GONE;
                someOneCanList.setVisibility(temp2);
                break;

            case R.id.savaBtn:

                showDialog();
                break;

            default:
                break;
        }
    }
}
