package com.example.chung.work;

import android.app.Activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethod;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by chung on 2017/10/1.
 */

public class act_7 extends Activity implements View.OnClickListener{
    private ImageButton avatarBtn;
    private ImageButton returnBtn;
    private TextView accountTv;
    private EditText nickNameEdt;
    private EditText areaEdt;
    private Button passwordEdtBtn;
    private Button myGoodsListBtn;
    private ListView myGoodList;
    //

    private ArrayAdapter<String> goodAdapter;

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout7);
        init();
    }

    private void init(){
        initView();
        initData();
    }

    private void initData(){
        setGoodApt();
    }

    private void initView(){
        avatarBtn = (ImageButton) findViewById(R.id.avatar);
        returnBtn = (ImageButton) findViewById(R.id.retrunMyMessage);
        accountTv = (TextView) findViewById(R.id.account);
        nickNameEdt = (EditText) findViewById(R.id.nickName);
        areaEdt = (EditText) findViewById(R.id.areaEdt);
        passwordEdtBtn = (Button) findViewById(R.id.changePassword);
        myGoodsListBtn = (Button) findViewById(R.id.goodListBtn);
        myGoodList = (ListView) findViewById(R.id.myGoodList);

        avatarBtn.setOnClickListener(this);
        returnBtn.setOnClickListener(this);
        passwordEdtBtn.setOnClickListener(this);
        myGoodsListBtn.setOnClickListener(this);

    }

    private void setGoodApt(){
        String[] strs =  { "abc", "abcd", "bcd", "bcde" };
        goodAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line, strs);
        myGoodList.setAdapter(goodAdapter);

        myGoodList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(act_7.this, act_13.class);
                startActivity(intent);
            }
        });
    }

    private void showDialog(){
        final AlertDialog mDialog = new AlertDialog.Builder(this).create();

        Window window = mDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);
        window.setWindowAnimations(R.style.popupAnimation);
        View view = View.inflate(this, R.layout.layout7_2, null);

        Button selectFromAblumBtn = (Button) view.findViewById(R.id.selectFromAblum);
        Button tokenBtn = (Button) view.findViewById(R.id.Token);
        Button cannelBtn = (Button) view.findViewById(R.id.cancelChange);

        selectFromAblumBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(act_7.this,"从相册选择",Toast.LENGTH_SHORT).show();
            }
        });

        tokenBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(act_7.this,"拍照",Toast.LENGTH_SHORT).show();
            }
        });

        cannelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialog.dismiss();
            }
        });

        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);//设置横向全屏
        mDialog.show();
        window.setContentView(view);

        mDialog.setCanceledOnTouchOutside(true);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.avatar:
                showDialog();
                break;

            case R.id.retrunMyMessage:
                finish();
                break;

            case R.id.changePassword:
                intent = new Intent(act_7.this, act_9.class);
                startActivity(intent);
                break;

            case R.id.goodListBtn:
                int temp;
                if(myGoodList.getVisibility() == View.GONE) temp = View.VISIBLE;
                else temp = View.GONE;
                myGoodList.setVisibility(temp);
                break;

            default:
                break;
        }
    }
}
