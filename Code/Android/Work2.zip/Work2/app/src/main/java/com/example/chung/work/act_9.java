package com.example.chung.work;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * Created by chung on 2017/10/1.
 */

public class act_9 extends Activity implements View.OnClickListener{
    private Button sendCheckNumberBtn;
    private Button sureChangeBtn;
    private Button cancleChangeBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout9);
        initView();
    }

    private void initView(){
        sendCheckNumberBtn = (Button) findViewById(R.id.sendCheckNumberBtn);
        sureChangeBtn = (Button) findViewById(R.id.sureChange);
        cancleChangeBtn = (Button) findViewById(R.id.cancelChange);

        sendCheckNumberBtn.setOnClickListener(this);
        sureChangeBtn.setOnClickListener(this);
        cancleChangeBtn.setOnClickListener(this);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sendCheckNumberBtn:
                break;

            case R.id.sureChange:

                finish();
                break;

            case R.id.cancelChange:
                finish();
                break;

            default:
                break;
        }
    }
}
